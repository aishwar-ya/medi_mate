import 'package:flutter/material.dart';
import 'package:barcode_widget/barcode_widget.dart';

class AddMedicationScreen extends StatefulWidget {
  final Map<String, dynamic>? initialData;

  const AddMedicationScreen({
    super.key,
    this.initialData,
  });

  @override
  State<AddMedicationScreen> createState() => _AddMedicationScreenState();
}

class _AddMedicationScreenState extends State<AddMedicationScreen> {
  static const Color purple = Color(0xFF7C3AED);
  static const Color purpleDark = Color(0xFF5B21B6);
  static const Color lavender = Color(0xFFEFE7FF);
  static const Color fieldFill = Color(0xFFF3EFFC);
  static const Color fieldBorder = Color(0xFFE6DDF7);
  static const Color pageTop = Color(0xFFF1EBFF);
  static const Color pageBottom = Color(0xFFFAF8FF);
  static const Color textDark = Color(0xFF211738);
  static const Color textMuted = Color(0xFF716A80);
  static const Color hintColor = Color(0xFF9B93AA);

  static const int _maxReminders = 6;

  dynamic _medicationId;

  final _nameController = TextEditingController();
  final _dosageController = TextEditingController();
  final _stockController = TextEditingController();
  final _barcodeController = TextEditingController();

  String _selectedFrequency = 'Once daily';
  List<String> _selectedTimes = ['8:00 AM'];

  final List<String> _frequencies = [
    'Once daily',
    'Twice daily',
    'As needed',
  ];

  @override
  void initState() {
    super.initState();

    if (widget.initialData != null) {
      final init = widget.initialData!;

      _medicationId = init['id'];
      _nameController.text = init['name']?.toString() ?? '';
      _dosageController.text = init['dosage']?.toString() ?? '';
      _stockController.text = init['stock_quantity']?.toString() ?? '30';

      final frequency = init['frequency']?.toString();
      if (frequency != null && _frequencies.contains(frequency)) {
        _selectedFrequency = frequency;
      }

      final barcode = init['barcode']?.toString() ?? '';
      if (barcode.isNotEmpty) {
        _barcodeController.text = barcode;
      } else if (_medicationId != null) {
        final idString = _medicationId.toString().padLeft(3, '0');
        _barcodeController.text = 'MEDIC$idString';
      }

      final reminderData = init['reminder_times'];
      if (reminderData is List && reminderData.isNotEmpty) {
        _selectedTimes = reminderData.map((item) => item.toString()).toList();
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _dosageController.dispose();
    _stockController.dispose();
    _barcodeController.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------------------
  // Time helpers
  // ---------------------------------------------------------------------------

  TimeOfDay _parseTimeOfDay(String value) {
    try {
      final parts = value.trim().split(' ');
      if (parts.length != 2) return TimeOfDay.now();

      final hm = parts[0].split(':');
      if (hm.length != 2) return TimeOfDay.now();

      int hour = int.parse(hm[0]);
      final minute = int.parse(hm[1]);
      final period = parts[1].toUpperCase();

      if (period == 'PM' && hour != 12) hour += 12;
      if (period == 'AM' && hour == 12) hour = 0;

      return TimeOfDay(hour: hour, minute: minute);
    } catch (_) {
      return TimeOfDay.now();
    }
  }

  Future<TimeOfDay?> _showPurpleTimePicker(TimeOfDay initial) {
    return showTimePicker(
      context: context,
      initialTime: initial,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: purple,
              onPrimary: Colors.white,
              surface: Colors.white,
              onSurface: textDark,
            ),
          ),
          child: child!,
        );
      },
    );
  }

  Future<void> _pickTime(int index) async {
    if (index < 0 || index >= _selectedTimes.length) return;

    final picked =
        await _showPurpleTimePicker(_parseTimeOfDay(_selectedTimes[index]));

    if (picked != null && mounted) {
      setState(() {
        _selectedTimes[index] = picked.format(context);
      });
    }
  }

  Future<void> _addAnotherTime() async {
    if (_selectedTimes.length >= _maxReminders) return;

    final picked = await _showPurpleTimePicker(TimeOfDay.now());

    if (picked != null && mounted) {
      setState(() {
        _selectedTimes.add(picked.format(context));
        if (_selectedFrequency == 'Once daily' && _selectedTimes.length > 1) {
          _selectedFrequency = 'Twice daily';
        }
      });
    }
  }

  void _removeTime(int index) {
    if (_selectedTimes.length <= 1) return;
    setState(() {
      _selectedTimes.removeAt(index);
    });
  }

  void _changeFrequency(String value) {
    setState(() {
      _selectedFrequency = value;

      if (value == 'Once daily') {
        _selectedTimes = [
          _selectedTimes.isNotEmpty ? _selectedTimes.first : '8:00 AM',
        ];
      } else if (value == 'Twice daily') {
        if (_selectedTimes.isEmpty) {
          _selectedTimes = ['8:00 AM', '8:00 PM'];
        } else if (_selectedTimes.length == 1) {
          _selectedTimes = [_selectedTimes.first, '8:00 PM'];
        }
      } else {
        _selectedTimes = [];
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Build
  // ---------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final isEditing = _medicationId != null;
    final width = MediaQuery.of(context).size.width;
    final compact = width < 500;

    return Scaffold(
      backgroundColor: pageBottom,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [pageTop, pageBottom],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              // Small decorative capsules, matching the reference mobile UI.
              Positioned(
                top: 7,
                right: compact ? 52 : 70,
                child: _capsule(
                  width: compact ? 27 : 44,
                  height: compact ? 11 : 18,
                  angle: -0.62,
                  left: const Color(0xFFE4DAFA),
                  right: const Color(0xFFF4ECFD),
                ),
              ),
              Positioned(
                top: 4,
                right: compact ? 18 : 22,
                child: _capsule(
                  width: compact ? 31 : 50,
                  height: compact ? 12 : 20,
                  angle: -0.75,
                  left: const Color(0xFFB89DF1),
                  right: const Color(0xFFDFD0FA),
                ),
              ),
              Positioned(
                top: compact ? 31 : 42,
                right: compact ? 5 : 8,
                child: _capsule(
                  width: compact ? 29 : 46,
                  height: compact ? 12 : 19,
                  angle: 0.72,
                  left: const Color(0xFFF2A7C5),
                  right: const Color(0xFFFBE0EC),
                ),
              ),
              Column(
                children: [
                  _buildTopBar(isEditing),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: EdgeInsets.fromLTRB(
                        compact ? 10 : 16,
                        compact ? 1 : 4,
                        compact ? 10 : 16,
                        compact ? 10 : 20,
                      ),
                      child: Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 720),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: compact ? 2 : 4),
                                child: Text(
                                  isEditing
                                      ? 'Update your medication'
                                      : 'Add a medicine to your medication list',
                                  style: TextStyle(
                                    fontSize: compact ? 8.5 : 13,
                                    color: textMuted,
                                  ),
                                ),
                              ),
                              SizedBox(height: compact ? 7 : 14),
                              _detailsCard(),
                              SizedBox(height: compact ? 7 : 14),
                              _scheduleCard(),
                              SizedBox(height: compact ? 7 : 14),
                              _barcodeCard(),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(
                      compact ? 10 : 16,
                      2,
                      compact ? 10 : 16,
                      compact ? 8 : 14,
                    ),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 720),
                        child: _saveButton(isEditing),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(bool isEditing) {
    final compact = MediaQuery.of(context).size.width < 500;
    return Padding(
      padding: EdgeInsets.fromLTRB(
        compact ? 3 : 8,
        compact ? 1 : 8,
        compact ? 8 : 18,
        compact ? 0 : 4,
      ),
      child: Row(
        children: [
          IconButton(
            padding: EdgeInsets.zero,
            constraints: BoxConstraints.tightFor(
              width: compact ? 28 : 40,
              height: compact ? 28 : 40,
            ),
            onPressed: () => Navigator.pop(context),
            icon: Icon(
              Icons.arrow_back_rounded,
              color: textDark,
              size: compact ? 17 : 24,
            ),
          ),
          Text(
            isEditing ? 'Edit Medication' : 'Add Medication',
            style: TextStyle(
              color: textDark,
              fontSize: compact ? 13.5 : 20,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Cards
  // ---------------------------------------------------------------------------

  Widget _detailsCard() {
    return _softCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _cardHeader(
            icon: Icons.medication_outlined,
            title: 'Medication Details',
            subtitle: 'Enter the basic information about your medicine',
            circular: false,
          ),
          const SizedBox(height: 9),
          _textField(
            label: 'Medication Name',
            controller: _nameController,
            hint: 'e.g., Atorvastatin',
            icon: Icons.medication_outlined,
          ),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _textField(
                  label: 'Dosage',
                  controller: _dosageController,
                  hint: 'e.g., 10mg',
                  icon: Icons.straighten_rounded,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _textField(
                  label: 'Stock',
                  optionalLabel: ' (Optional)',
                  controller: _stockController,
                  hint: 'e.g., 30',
                  icon: Icons.inventory_2_rounded,
                  keyboardType: TextInputType.number,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _scheduleCard() {
    final compact = MediaQuery.of(context).size.width < 500;
    return _softCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _cardHeader(
            icon: Icons.access_time_rounded,
            title: 'Schedule',
            subtitle: 'Choose when you need to take this medicine',
            circular: true,
          ),
          SizedBox(height: compact ? 8 : 16),
          Text('Frequency', style: TextStyle(
            color: textDark,
            fontSize: compact ? 8.5 : 13,
            fontWeight: FontWeight.w700,
          )),
          SizedBox(height: compact ? 4 : 8),
          Container(
            height: compact ? 31 : 48,
            padding: EdgeInsets.symmetric(horizontal: compact ? 9 : 14),
            decoration: BoxDecoration(
              color: fieldFill,
              borderRadius: BorderRadius.circular(compact ? 8 : 14),
              border: Border.all(color: fieldBorder),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedFrequency,
                isExpanded: true,
                icon: Icon(Icons.keyboard_arrow_down_rounded,
                    color: purple, size: compact ? 15 : 20),
                dropdownColor: Colors.white,
                style: TextStyle(
                  color: textDark,
                  fontSize: compact ? 8.5 : 14,
                  fontWeight: FontWeight.w600,
                ),
                items: _frequencies.map((item) {
                  return DropdownMenuItem<String>(
                    value: item,
                    child: Text(item),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) _changeFrequency(value);
                },
              ),
            ),
          ),
          if (_selectedFrequency != 'As needed') ...[
            SizedBox(height: compact ? 8 : 16),
            Text('Reminder Time(s)', style: TextStyle(
              color: textDark,
              fontSize: compact ? 8.5 : 13,
              fontWeight: FontWeight.w700,
            )),
            SizedBox(height: compact ? 4 : 8),
            for (int i = 0; i < _selectedTimes.length; i++) _timeRow(i),
            if (_selectedTimes.length < _maxReminders)
              Center(
                child: TextButton.icon(
                  onPressed: _addAnotherTime,
                  style: TextButton.styleFrom(
                    minimumSize: Size.zero,
                    padding: EdgeInsets.symmetric(vertical: compact ? 2 : 4),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  icon: Icon(Icons.add_circle_rounded,
                      color: purple, size: compact ? 11 : 18),
                  label: Text(
                    'Add Another Time',
                    style: TextStyle(
                      color: purple,
                      fontSize: compact ? 7.5 : 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
          ] else ...[
            SizedBox(height: compact ? 7 : 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: fieldFill,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline_rounded, color: purple, size: 19),
                  SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      'No fixed reminder will be scheduled. Take this medicine as needed.',
                      style: TextStyle(color: textMuted, fontSize: 12, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _timeRow(int index) {
    final compact = MediaQuery.of(context).size.width < 500;
    return GestureDetector(
      onTap: () => _pickTime(index),
      child: Container(
        width: double.infinity,
        margin: EdgeInsets.only(bottom: compact ? 4 : 8),
        padding: EdgeInsets.symmetric(
          horizontal: compact ? 7 : 12,
          vertical: compact ? 4 : 8,
        ),
        decoration: BoxDecoration(
          color: fieldFill,
          borderRadius: BorderRadius.circular(compact ? 8 : 14),
          border: Border.all(color: fieldBorder),
        ),
        child: Row(
          children: [
            Container(
              width: compact ? 23 : 34,
              height: compact ? 23 : 34,
              decoration: const BoxDecoration(
                color: lavender,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.access_time_rounded,
                  color: purple, size: compact ? 13 : 19),
            ),
            SizedBox(width: compact ? 7 : 12),
            Expanded(
              child: Text(
                _selectedTimes[index],
                style: TextStyle(
                  color: textDark,
                  fontSize: compact ? 8.5 : 15,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            if (index > 0)
              GestureDetector(
                onTap: () => _removeTime(index),
                child: Padding(
                  padding: EdgeInsets.only(right: compact ? 7 : 12),
                  child: Icon(Icons.close_rounded,
                      color: textMuted, size: compact ? 13 : 19),
                ),
              ),
            Icon(Icons.edit_rounded, color: purple, size: compact ? 13 : 18),
          ],
        ),
      ),
    );
  }

  Widget _barcodeCard() {
    final barcode = _barcodeController.text.trim();
    final compact = MediaQuery.of(context).size.width < 500;
    return _softCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _cardHeader(
            icon: Icons.qr_code_2_rounded,
            title: 'Medicine Barcode',
            subtitle: 'Use this barcode to quickly identify the medicine',
            circular: false,
          ),
          SizedBox(height: compact ? 7 : 14),
          TextField(
            controller: _barcodeController,
            onChanged: (_) => setState(() {}),
            style: TextStyle(
              color: textDark,
              fontSize: compact ? 8.5 : 14,
              fontWeight: FontWeight.w600,
            ),
            decoration: InputDecoration(
              hintText: 'Barcode ID (Optional)',
              hintStyle: TextStyle(color: hintColor, fontSize: compact ? 8 : 14),
              prefixIcon: Icon(Icons.qr_code_2_rounded,
                  color: purple, size: compact ? 14 : 22),
              prefixIconConstraints: compact
                  ? const BoxConstraints(minWidth: 30, minHeight: 30)
                  : null,
              filled: true,
              fillColor: fieldFill,
              contentPadding: EdgeInsets.symmetric(
                  horizontal: compact ? 8 : 14, vertical: compact ? 7 : 16),
              border: _inputBorder(fieldBorder),
              enabledBorder: _inputBorder(fieldBorder),
              focusedBorder: _inputBorder(purple, width: 1.4),
            ),
          ),
          if (barcode.isNotEmpty) ...[
            SizedBox(height: compact ? 7 : 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: fieldBorder),
              ),
              child: Column(
                children: [
                  const Text('Scannable Code 128', style: TextStyle(
                    color: textDark, fontSize: 13, fontWeight: FontWeight.w800,
                  )),
                  const SizedBox(height: 12),
                  BarcodeWidget(
                    barcode: Barcode.code128(
                      useCode128A: false,
                      useCode128B: true,
                      useCode128C: false,
                    ),
                    data: barcode,
                    width: 420,
                    height: 100,
                    color: Colors.black,
                    backgroundColor: Colors.white,
                    drawText: true,
                    textPadding: 8,
                  ),
                  const SizedBox(height: 6),
                  const Text('Scan this Code 128 barcode with MediMate.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: textMuted, fontSize: 12)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _saveButton(bool isEditing) {
    final compact = MediaQuery.of(context).size.width < 500;
    return SizedBox(
      width: double.infinity,
      height: compact ? 30 : 54,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [purple, purpleDark],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(compact ? 9 : 16),
          boxShadow: [
            BoxShadow(
              color: purple.withOpacity(0.22),
              blurRadius: compact ? 8 : 16,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: ElevatedButton.icon(
          onPressed: _saveMedication,
          icon: Icon(
            isEditing ? Icons.check_rounded : Icons.add_rounded,
            size: compact ? 13 : 22,
          ),
          label: Text(
            isEditing ? 'Update Medication' : 'Save Medication',
            style: TextStyle(
              fontSize: compact ? 9 : 16,
              fontWeight: FontWeight.w700,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            foregroundColor: Colors.white,
            shadowColor: Colors.transparent,
            elevation: 0,
            padding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(compact ? 9 : 16),
            ),
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Reusable widgets
  // ---------------------------------------------------------------------------

  Widget _cardHeader({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool circular,
  }) {
    final compact = MediaQuery.of(context).size.width < 500;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: compact ? 28 : 40,
          height: compact ? 28 : 40,
          decoration: BoxDecoration(
            color: lavender,
            shape: circular ? BoxShape.circle : BoxShape.rectangle,
            borderRadius: circular ? null : BorderRadius.circular(compact ? 8 : 12),
          ),
          child: Icon(icon, color: purple, size: compact ? 15 : 22),
        ),
        SizedBox(width: compact ? 7 : 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: textDark,
                  fontSize: compact ? 9.5 : 15,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 1),
              Text(
                subtitle,
                style: TextStyle(
                  color: textMuted,
                  fontSize: compact ? 6.5 : 11.5,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }

  OutlineInputBorder _inputBorder(Color color, {double width = 1}) {
    return OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: color, width: width),
    );
  }

  Widget _textField({
    required String label,
    String optionalLabel = '',
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
  }) {
    final compact = MediaQuery.of(context).size.width < 500;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text.rich(
          TextSpan(
            text: label,
            style: TextStyle(
              color: textDark,
              fontSize: compact ? 7.5 : 13,
              fontWeight: FontWeight.w700,
            ),
            children: [
              if (optionalLabel.isNotEmpty)
                TextSpan(
                  text: optionalLabel,
                  style: TextStyle(
                    color: textMuted,
                    fontSize: compact ? 6.5 : 11.5,
                    fontWeight: FontWeight.w400,
                  ),
                ),
            ],
          ),
        ),
        SizedBox(height: compact ? 4 : 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          style: TextStyle(
            color: textDark,
            fontSize: compact ? 8 : 14,
            fontWeight: FontWeight.w600,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
              color: hintColor,
              fontSize: compact ? 7.5 : 14,
            ),
            prefixIcon: Icon(icon, color: purple, size: compact ? 13 : 20),
            prefixIconConstraints: compact
                ? const BoxConstraints(minWidth: 27, minHeight: 27)
                : null,
            filled: true,
            fillColor: fieldFill,
            contentPadding: EdgeInsets.symmetric(
              horizontal: compact ? 7 : 12,
              vertical: compact ? 6 : 15,
            ),
            border: _inputBorder(fieldBorder),
            enabledBorder: _inputBorder(fieldBorder),
            focusedBorder: _inputBorder(purple, width: 1.4),
          ),
        ),
      ],
    );
  }

  Widget _softCard({required Widget child}) {
    final compact = MediaQuery.of(context).size.width < 500;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(compact ? 9 : 16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.94),
        borderRadius: BorderRadius.circular(compact ? 10 : 18),
        border: Border.all(color: const Color(0xFFEDE6FA)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6D28D9).withOpacity(0.045),
            blurRadius: compact ? 8 : 18,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _capsule({
    required double width,
    required double height,
    required double angle,
    required Color left,
    required Color right,
  }) {
    return Transform.rotate(
      angle: angle,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(height),
        child: SizedBox(
          width: width,
          height: height,
          child: Row(
            children: [
              Expanded(child: Container(color: left)),
              Expanded(child: Container(color: right)),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Save
  // ---------------------------------------------------------------------------

  void _saveMedication() {
    if (_nameController.text.trim().isEmpty ||
        _dosageController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all required fields'),
        ),
      );
      return;
    }

    final stockQuantity = int.tryParse(_stockController.text.trim()) ?? 30;

    final Map<String, dynamic> med = {
      if (_medicationId != null) 'id': _medicationId,
      'name': _nameController.text.trim(),
      'dosage': _dosageController.text.trim(),
      'frequency': _selectedFrequency,
      'stock_quantity': stockQuantity,
      if (_barcodeController.text.trim().isNotEmpty)
        'barcode': _barcodeController.text.trim(),
    };

    if (_selectedFrequency != 'As needed' && _selectedTimes.isNotEmpty) {
      med['reminder_times'] = List<String>.from(_selectedTimes);

      final timeStr = _selectedTimes.first;

      try {
        final parts = timeStr.trim().split(' ');

        if (parts.length == 2) {
          final hm = parts[0].split(':');
          int hour = int.parse(hm[0]);
          final minute = int.parse(hm[1]);
          final ampm = parts[1].toUpperCase();

          if (ampm == 'PM' && hour != 12) hour += 12;
          if (ampm == 'AM' && hour == 12) hour = 0;

          final now = DateTime.now();
          DateTime nextDose = DateTime(
            now.year,
            now.month,
            now.day,
            hour,
            minute,
          );

          if (nextDose.isBefore(now)) {
            nextDose = nextDose.add(const Duration(days: 1));
          }

          med['next_dose'] = nextDose.toIso8601String();
        }
      } catch (_) {
        // Keep the medication data even if the display time
        // cannot be parsed.
      }
    } else {
      med['reminder_times'] = <String>[];
      med['next_dose'] = null;
    }

    Navigator.pop(context, med);
  }
}